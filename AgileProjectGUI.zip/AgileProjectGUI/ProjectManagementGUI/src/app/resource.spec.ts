import { Resource } from './resource';

describe('Resource', () => {
  it('should create an instance', () => {
    expect(new Resource()).toBeTruthy();
  });
});
