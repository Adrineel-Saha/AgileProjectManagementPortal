export class Client {
    
    id!: number;
    name!: string;
    fullName!: number;
    phoneNumber!: string;
    emailAddress!: string;
}
