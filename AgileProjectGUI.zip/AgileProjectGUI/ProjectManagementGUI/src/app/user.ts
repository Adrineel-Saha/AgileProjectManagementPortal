export class User {
    userName!: string;
    password!: string;
    role!: string;
    isAccountLocked!: boolean;
}
