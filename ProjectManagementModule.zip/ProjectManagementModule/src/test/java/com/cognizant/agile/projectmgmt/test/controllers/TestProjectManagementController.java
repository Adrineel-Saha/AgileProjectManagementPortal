package com.cognizant.agile.projectmgmt.test.controllers;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.ResponseEntity;

import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import com.cognizant.agile.projectmgmt.controllers.ProjectManagementController;
import com.cognizant.agile.projectmgmt.dto.*;

import com.cognizant.agile.projectmgmt.main.ProjectManagementModuleApplication;
import com.cognizant.agile.projectmgmt.services.*;

@SpringBootTest(classes=ProjectManagementModuleApplication.class)
public class TestProjectManagementController {
	@Mock
	private ClientService clientService;
	
	@Mock
	private ProjectService projectService;
	
	@Mock
	private ResourceService resourceService;
	
	@InjectMocks
	private ProjectManagementController projectManagementController;
	
	@Autowired
	private LocalValidatorFactoryBean validator;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);		
	}
	
	@Test
	public void testGetAllClientsPositiveAssertReturnValue() {
		List<ClientDTO> CDTOList=new ArrayList<>();
		ClientDTO CDTO=new ClientDTO();
		CDTO.setId(1);
		CDTO.setName("Client A");
		CDTO.setFullName(123456789);
		CDTO.setPhoneNumber("+9475612033");
		CDTO.setEmailAddress("clienta@gmail.com");
		CDTOList.add(CDTO);
		
		try {
			when(clientService.getAllClients()).thenReturn(CDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllClients();
			List<ClientDTO> actualCDTOList=(List<ClientDTO>)responseEntity.getBody();
			assertTrue(actualCDTOList.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllClientsPositiveAssertStatusCode() {
		List<ClientDTO> CDTOList=new ArrayList<>();
		ClientDTO CDTO=new ClientDTO();
		CDTO.setId(2);
		CDTO.setName("Client B");
		CDTO.setFullName(234567891);
		CDTO.setPhoneNumber("+91263201710");
		CDTO.setEmailAddress("clientb@gmail.com");
		CDTOList.add(CDTO);
		
		try {
			when(clientService.getAllClients()).thenReturn(CDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllClients();
			assertEquals(200,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllClientsNegativeAssertReturnValue() {
		List<ClientDTO> CDTOList=new ArrayList<>();
		try {
			when(clientService.getAllClients()).thenReturn(CDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllClients();
			assertNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllClientsNegativeStatusCode() {
		List<ClientDTO> CDTOList=new ArrayList<>();
		try {
			when(clientService.getAllClients()).thenReturn(CDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllClients();
			assertEquals(400,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testAddProjectWhenProjectIsValid() {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(1);
		PDTO.setTitle("Proj A");
		PDTO.setBudget(10000);
		PDTO.setStartDate(new Date(2024,2,1));
		PDTO.setExpectedEndDate(new Date(2024,3,15));
		PDTO.setCreatedOn(new Date(2024,1,1));
		PDTO.setStatus("New");
		PDTO.setLastUpdatedOn(new Date(2024,2,1));
		PDTO.setClientId(5);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(5);
//		CDTO.setName("Client E");
//		CDTO.setFullName(567891234);
//		CDTO.setPhoneNumber("+9474052945");
//		CDTO.setEmailAddress("cliente@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
		
		validator.validate(PDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation)); 
	}
	
	@Test
	public void testAddProjectPositiveAssertStatusCode() {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(2);
		PDTO.setTitle("Proj B");
		PDTO.setBudget(15000);
		PDTO.setStartDate(new Date(2024,2,5));
		PDTO.setExpectedEndDate(new Date(2024,4,20));
		PDTO.setCreatedOn(new Date(2024,1,5));
		PDTO.setStatus("InProgtess");
		PDTO.setLastUpdatedOn(new Date(2024,2,5));
		PDTO.setClientId(4);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(4);
//		CDTO.setName("Client D");
//		CDTO.setFullName(456789123);
//		CDTO.setPhoneNumber("+9433663287");
//		CDTO.setEmailAddress("clientd@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
		
		try {
			when(projectService.addProject(Mockito.any())).thenReturn(PDTO);
			ResponseEntity<?> responseEntity=projectManagementController.addProject(PDTO);
			assertEquals(201,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testAddProjectWhenProjectIsNotValid() {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(2);
		PDTO.setTitle("Proj B");
		PDTO.setBudget(15000);
		PDTO.setStartDate(new Date(2024,2,5));
		PDTO.setExpectedEndDate(new Date(2024,4,20));
		PDTO.setCreatedOn(new Date(2024,1,5));
		PDTO.setStatus("InProgressCompleted");
		PDTO.setLastUpdatedOn(new Date(2024,2,5));
		PDTO.setClientId(4);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(4);
//		CDTO.setName("Client D");
//		CDTO.setFullName(456789123);
//		CDTO.setPhoneNumber("+9433663287");
//		CDTO.setEmailAddress("clientd@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
		
		validator.validate(PDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation)); 
	}
	
	@Test
	public void testAddProjectNegativeAssertStatusCode() {
		ProjectDTO PDTO=null;
		
		try {
			when(projectService.addProject(Mockito.any())).thenReturn(PDTO);
			ResponseEntity<?> responseEntity=projectManagementController.addProject(PDTO);
			assertEquals(400,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testGetAllProjectsPositiveAssertReturnValue() {
		List<ProjectDTO> PDTOList=new ArrayList<>();
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(1);
		PDTO.setTitle("Proj A");
		PDTO.setBudget(10000);
		PDTO.setStartDate(new Date(2024,2,1));
		PDTO.setExpectedEndDate(new Date(2024,3,15));
		PDTO.setCreatedOn(new Date(2024,1,1));
		PDTO.setStatus("New");
		PDTO.setLastUpdatedOn(new Date(2024,2,1));
		PDTO.setClientId(5);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(5);
//		CDTO.setName("Client E");
//		CDTO.setFullName(567891234);
//		CDTO.setPhoneNumber("+9474052945");
//		CDTO.setEmailAddress("cliente@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
		PDTOList.add(PDTO);
		
		try {
			when(projectService.getAllProjects()).thenReturn(PDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllProjects();
			List<ProjectDTO> actualPDTOList=(List<ProjectDTO>)responseEntity.getBody();
			assertTrue(actualPDTOList.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllProjectsPositiveAssertStatusCode() {
		List<ProjectDTO> PDTOList=new ArrayList<>();
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(2);
		PDTO.setTitle("Proj B");
		PDTO.setBudget(15000);
		PDTO.setStartDate(new Date(2024,2,5));
		PDTO.setExpectedEndDate(new Date(2024,4,20));
		PDTO.setCreatedOn(new Date(2024,1,5));
		PDTO.setStatus("InProgtess");
		PDTO.setLastUpdatedOn(new Date(2024,2,5));
		PDTO.setClientId(4);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(4);
//		CDTO.setName("Client D");
//		CDTO.setFullName(456789123);
//		CDTO.setPhoneNumber("+9433663287");
//		CDTO.setEmailAddress("clientd@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
		PDTOList.add(PDTO);
		
		try {
			when(projectService.getAllProjects()).thenReturn(PDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllProjects();
			assertEquals(200,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllProjectsNegativeAssertReturnValue() {
		List<ProjectDTO> PDTOList=new ArrayList<>();
		try {
			when(projectService.getAllProjects()).thenReturn(PDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllProjects();
			assertNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllProjectsNegativeStatusCode() {
		List<ProjectDTO> PDTOList=new ArrayList<>();
		try {
			when(projectService.getAllProjects()).thenReturn(PDTOList);
			ResponseEntity<?> responseEntity=projectManagementController.getAllProjects();
			assertEquals(400,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	void testUpdateProjectWhenProjectIsValid() {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(4);
		PDTO.setTitle("Proj D");
		PDTO.setBudget(25000);
		PDTO.setStartDate(new Date(2024,2,15));
		PDTO.setExpectedEndDate(new Date(2024,6,15));
		PDTO.setCreatedOn(new Date(2024,1,15));
		PDTO.setStatus("InProgress");
		PDTO.setLastUpdatedOn(new Date(2024,2,15));
		PDTO.setClientId(2);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(2);
//		CDTO.setName("Client B");
//		CDTO.setFullName(234567891);
//		CDTO.setPhoneNumber("+9126320710");
//		CDTO.setEmailAddress("clientb@gmail.com");
//		
//		PDTO.setClientDTO(CDTO); 
		
		validator.validate(PDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation)); 
	}
	
	@Test
	void testUpdateProjectPositiveAssertStatusCode() {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(4);
		PDTO.setTitle("Proj D");
		PDTO.setBudget(25000);
		PDTO.setStartDate(new Date(2024,2,15));
		PDTO.setExpectedEndDate(new Date(2024,6,15));
		PDTO.setCreatedOn(new Date(2024,1,15));
		PDTO.setStatus("InProgress");
		PDTO.setLastUpdatedOn(new Date(2024,2,15));
		PDTO.setClientId(2);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(2);
//		CDTO.setName("Client B");
//		CDTO.setFullName(234567891);
//		CDTO.setPhoneNumber("+9126320710");
//		CDTO.setEmailAddress("clientb@gmail.com");
//		
//		PDTO.setClientDTO(CDTO); 
		
		when(projectService.updateProject(Mockito.any())).thenReturn(PDTO);
		try {
			when(projectService.updateProject(Mockito.any())).thenReturn(PDTO);
			ResponseEntity<?> responseEntity=projectManagementController.updateProject(4, PDTO);
			assertEquals(202,responseEntity.getStatusCodeValue());
		} catch (Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	void testUpdateProjectWhenProjectIsNotValid() {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(1);
		PDTO.setTitle("Proj A");
		PDTO.setBudget(10000);
		PDTO.setStartDate(new Date(2024,2,1));
		PDTO.setExpectedEndDate(new Date(2024,3,15));
		PDTO.setCreatedOn(new Date(2024,1,1));
		PDTO.setStatus("InProgressCancelled");
		PDTO.setLastUpdatedOn(new Date(2024,2,1));
		PDTO.setClientId(5);
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(5);
//		CDTO.setName("Client E");
//		CDTO.setFullName(567891234);
//		CDTO.setPhoneNumber("+9474052945");
//		CDTO.setEmailAddress("cliente@gmail.com");
//		PDTO.setClientDTO(CDTO); 
		
		validator.validate(PDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation)); 
	}
	
	@Test
	void testUpdateProjectNegativeAssertStatusCode() {
		ProjectDTO PDTO=null;
		
		try {
			when(projectService.updateProject(Mockito.any())).thenReturn(PDTO);
			ResponseEntity<?> responseEntity=projectManagementController.updateProject(4, PDTO);
			assertEquals(400,responseEntity.getStatusCodeValue());
		} catch (Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testAddResourceWhenResourceIsValid() {
		ResourceDTO RDTO=new ResourceDTO();
		RDTO.setUserId("User 2");
		RDTO.setFirstName("Yash");
		RDTO.setLastName("Biswakarma");
		RDTO.setEmail("biswakarmayash@cognizant.com");
		RDTO.setPhoneNumber("+876902341");
		RDTO.setRole("Tester");
		RDTO.setProjectCode(4);
//		ProjectDTO PDTO=new ProjectDTO();
//		PDTO.setProjectCode(4);
//		PDTO.setTitle("Proj D");
//		PDTO.setBudget(25000);
//		PDTO.setStartDate(new Date(2024,2,15));
//		PDTO.setExpectedEndDate(new Date(2024,6,15));
//		PDTO.setCreatedOn(new Date(2024,1,15));
//		PDTO.setStatus("Delayed");
//		PDTO.setLastUpdatedOn(new Date(2024,2,15));
//		
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(2);
//		CDTO.setName("Client B");
//		CDTO.setFullName(234567891);
//		CDTO.setPhoneNumber("+9126320710");
//		CDTO.setEmailAddress("clientb@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
//		RDTO.setProjectDTO(PDTO);		

		validator.validate(RDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation)); 
	}
	
	@Test
	public void testAddResourcePositiveAssertReturnValue() {
		ResourceDTO RDTO=new ResourceDTO();
		RDTO.setUserId("User 2");
		RDTO.setFirstName("Yash");
		RDTO.setLastName("Biswakarma");
		RDTO.setEmail("biswakarmayash@cognizant.com");
		RDTO.setPhoneNumber("+876902341");
		RDTO.setRole("Tester");
		RDTO.setProjectCode(4);
//		ProjectDTO PDTO=new ProjectDTO();
//		PDTO.setProjectCode(4);
//		PDTO.setTitle("Proj D");
//		PDTO.setBudget(25000);
//		PDTO.setStartDate(new Date(2024,2,15));
//		PDTO.setExpectedEndDate(new Date(2024,6,15));
//		PDTO.setCreatedOn(new Date(2024,1,15));
//		PDTO.setStatus("Delayed");
//		PDTO.setLastUpdatedOn(new Date(2024,2,15));
//		
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(2);
//		CDTO.setName("Client B");
//		CDTO.setFullName(234567891);
//		CDTO.setPhoneNumber("+9126320710");
//		CDTO.setEmailAddress("clientb@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
//		RDTO.setProjectDTO(PDTO);
		
		try {
			when(resourceService.addResource(Mockito.any())).thenReturn(RDTO);
			ResponseEntity<?> responseEntity=projectManagementController.addResource(RDTO);
			assertNotNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testAddResourcePositiveAssertStatusCode() {
		ResourceDTO RDTO=new ResourceDTO();
		RDTO.setUserId("User 2");
		RDTO.setFirstName("Yash");
		RDTO.setLastName("Biswakarma");
		RDTO.setEmail("biswakarmayash@cognizant.com");
		RDTO.setPhoneNumber("+876902341");
		RDTO.setRole("Tester");
		RDTO.setProjectCode(4);
//		ProjectDTO PDTO=new ProjectDTO();
//		PDTO.setProjectCode(4);
//		PDTO.setTitle("Proj D");
//		PDTO.setBudget(25000);
//		PDTO.setStartDate(new Date(2024,2,15));
//		PDTO.setExpectedEndDate(new Date(2024,6,15));
//		PDTO.setCreatedOn(new Date(2024,1,15));
//		PDTO.setStatus("Delayed");
//		PDTO.setLastUpdatedOn(new Date(2024,2,15));
//		
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(2);
//		CDTO.setName("Client B");
//		CDTO.setFullName(234567891);
//		CDTO.setPhoneNumber("+9126320710");
//		CDTO.setEmailAddress("clientb@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
//		RDTO.setProjectDTO(PDTO);
		
		try {
			when(resourceService.addResource(Mockito.any())).thenReturn(RDTO);
			ResponseEntity<?> responseEntity=projectManagementController.addResource(RDTO);
			assertEquals(201,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testAddResourceWhenResourceIsNotValid() {
		ResourceDTO RDTO=new ResourceDTO();
		RDTO.setUserId("User 1");
		RDTO.setFirstName("Adrineel");
		RDTO.setLastName("Saha");
		RDTO.setEmail("adrineelsaha@cognizant.com");
		RDTO.setPhoneNumber("+93849234");
		RDTO.setRole("DeveloperTester");
		RDTO.setProjectCode(3);
//		ProjectDTO PDTO=new ProjectDTO();
//		PDTO.setProjectCode(3);
//		PDTO.setTitle("Proj C");
//		PDTO.setBudget(20000);
//		PDTO.setStartDate(new Date(2024,2,10));
//		PDTO.setExpectedEndDate(new Date(2024,5,1));
//		PDTO.setCreatedOn(new Date(2024,1,10));
//		PDTO.setStatus("InProgress");
//		PDTO.setLastUpdatedOn(new Date(2024,2,10));
//
//		ClientDTO CDTO=new ClientDTO();
//		CDTO.setId(3);
//		CDTO.setName("Client C");
//		CDTO.setFullName(345678912);
//		CDTO.setPhoneNumber("+8515082009");
//		CDTO.setEmailAddress("clientc@gmail.com");
//		
//		PDTO.setClientDTO(CDTO);
//		RDTO.setProjectDTO(PDTO);

		validator.validate(RDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation)); 
	}
	
	@Test
	public void testAddResourceNegativeAssertReturnValue() {
		ResourceDTO RDTO=null;
		
		try {
			when(resourceService.addResource(Mockito.any())).thenReturn(RDTO);
			ResponseEntity<?> responseEntity=projectManagementController.addResource(RDTO);
			assertNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testAddResourceNegativeAssertStatusCode() {
		ResourceDTO RDTO=null;
		
		try {
			when(resourceService.addResource(Mockito.any())).thenReturn(RDTO);
			ResponseEntity<?> responseEntity=projectManagementController.addResource(RDTO);
			assertEquals(400,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
}
