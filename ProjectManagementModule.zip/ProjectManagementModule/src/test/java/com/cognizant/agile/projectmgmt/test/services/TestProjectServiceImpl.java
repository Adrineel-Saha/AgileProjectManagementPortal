package com.cognizant.agile.projectmgmt.test.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.*;
import org.mockito.*;
import org.modelmapper.ModelMapper;

import com.cognizant.agile.projectmgmt.dto.*;
import com.cognizant.agile.projectmgmt.entities.*;
import com.cognizant.agile.projectmgmt.repositories.*;
import com.cognizant.agile.projectmgmt.services.ProjectServiceImpl;

public class TestProjectServiceImpl {
	@Mock
	private ProjectRepository projectRepository;
	@Mock
	private ClientRepository clientRepository;
	@InjectMocks
	private ProjectServiceImpl projectServiceImpl;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@AfterEach
	void tearDown() throws Exception {
		
	} 

	@Test
	public void testAddProjectPositive() {
	try {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(3);
		PDTO.setTitle("Proj C");
		PDTO.setBudget(20000);
		PDTO.setStartDate(new Date(2024,2,10));
		PDTO.setExpectedEndDate(new Date(2024,5,1));
		PDTO.setCreatedOn(new Date(2024,1,10));
		PDTO.setStatus("Completed");
		PDTO.setLastUpdatedOn(new Date(2024,2,10));
		PDTO.setClientId(3);
		
		Client C=new Client();
		C.setId(3);
		C.setName("Client C");
		C.setFullName(345678912);
		C.setPhoneNumber("+8515082009");
		C.setEmailAddress("clientc@gmail.com");
		
		when(clientRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(C));
		Project projectMock=new ModelMapper().map(PDTO, Project.class);
//		Client clientMock=new ModelMapper().map(CDTO, Client.class);
		projectMock.setClient(C);
		
		when(projectRepository.save(Mockito.any())).thenReturn(projectMock);
		ProjectDTO actualPDTO=projectServiceImpl.addProject(PDTO);
		assertNotEquals(null,actualPDTO);
	}catch(Exception e) {
		//e.printStackTrace();
	//	System.out.println(e);
		assertTrue(false);
		}
	} 
	
	@Test
	public void testAddProjectNegative() {
	try {
		ProjectDTO PDTO=new ProjectDTO();
		PDTO.setProjectCode(2);
		PDTO.setTitle("Proj B");
		PDTO.setBudget(15000);
		PDTO.setStartDate(new Date(2024,2,5));
		PDTO.setExpectedEndDate(new Date(2024,4,20));
		PDTO.setCreatedOn(new Date(2024,1,5));
		PDTO.setStatus("InProgressCompleted");
		PDTO.setLastUpdatedOn(new Date(2024,2,5));
		PDTO.setClientId(4);
		
		Client C=new Client();
		C.setId(4);
		C.setName("Client D");
		C.setFullName(456789123);
		C.setPhoneNumber("+9433663287");
		C.setEmailAddress("clientd@gmail.com");
		
		when(clientRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(C));
		Project projectMock=new ModelMapper().map(PDTO, Project.class);
//		Client clientMock=new ModelMapper().map(CDTO, Client.class);
		projectMock.setClient(C);
		
		when(projectRepository.save(Mockito.any())).thenReturn(projectMock);
		projectServiceImpl.addProject(PDTO);
		assertTrue(false);
	}catch(Exception e) {
		//e.printStackTrace();
	//	System.out.println(e);
		assertTrue(true);
		}
	} 
	
	@Test
	public void testUpdateProjectPositive() {
		try {		
			Project P=new Project();
			P.setProjectCode(1);
			P.setTitle("Proj A");
			P.setBudget(10000);
			P.setStartDate(new Date(2024,2,1));
			P.setExpectedEndDate(new Date(2024,3,15));
			P.setCreatedOn(new Date(2024,1,1));
			P.setStatus("New");
			P.setLastUpdatedOn(new Date(2024,2,1));
			
			Client C=new Client();
			C.setId(5);
			C.setName("Client E");
			C.setFullName(567891234);
			C.setPhoneNumber("+9474052945");
			C.setEmailAddress("cliente@gmail.com");
			P.setClient(C); 
			
			Optional<Project> projectOptional=Optional.of(P);
			when(projectRepository.findById(1)).thenReturn(projectOptional);
			
			ProjectDTO PDTO=new ProjectDTO();
			PDTO.setProjectCode(1);
			PDTO.setTitle("Proj A");
			PDTO.setBudget(10000);
			PDTO.setStartDate(new Date(2024,2,1));
			PDTO.setExpectedEndDate(new Date(2024,3,15));
			PDTO.setCreatedOn(new Date(2024,1,1));
			PDTO.setStatus("Completed");
			PDTO.setLastUpdatedOn(new Date(2024,2,1));
			PDTO.setClientId(5);
//			ClientDTO CDTO=new ClientDTO();
//			CDTO.setId(5);
//			CDTO.setName("Client E");
//			CDTO.setFullName(567891234);
//			CDTO.setPhoneNumber("+9474052945");
//			CDTO.setEmailAddress("cliente@gmail.com");
//			PDTO.setClientDTO(CDTO); 
			
			Project updatedProject=new ModelMapper().map(PDTO, Project.class);
//			Client newClient=new ModelMapper().map(CDTO, Client.class);
			updatedProject.setClient(C);
			
			when(projectRepository.save(P)).thenReturn(updatedProject);
			ProjectDTO actualPDTO=projectServiceImpl.updateProject(PDTO);
			assertNotEquals(null,actualPDTO);
			}catch(Exception e) {
			//	System.out.println(e);
				assertTrue(false);
			}
	}
	
	@Test
	public void testUpdateProjectNegative() {
		try {
			Project P=new Project();
			P.setProjectCode(1);
			P.setTitle("Proj A");
			P.setBudget(10000);
			P.setStartDate(new Date(2024,2,1));
			P.setExpectedEndDate(new Date(2024,3,15));
			P.setCreatedOn(new Date(2024,1,1));
			P.setStatus("New");
			P.setLastUpdatedOn(new Date(2024,2,1));
			
			Client C=new Client();
			C.setId(5);
			C.setName("Client E");
			C.setFullName(567891234);
			C.setPhoneNumber("+9474052945");
			C.setEmailAddress("cliente@gmail.com");
			P.setClient(C); 
			
			Optional<Project> projectOptional=Optional.of(P);
			when(projectRepository.findById(1)).thenReturn(projectOptional);
			
			ProjectDTO PDTO=new ProjectDTO();
			PDTO.setProjectCode(1);
			PDTO.setTitle("Proj A");
			PDTO.setBudget(10000);
			PDTO.setStartDate(new Date(2024,2,1));
			PDTO.setExpectedEndDate(new Date(2024,3,15));
			PDTO.setCreatedOn(new Date(2024,1,1));
			PDTO.setStatus("InProgressCancelled");
			PDTO.setLastUpdatedOn(new Date(2024,2,1));
			PDTO.setClientId(5);
//			ClientDTO CDTO=new ClientDTO();
//			CDTO.setId(5);
//			CDTO.setName("Client E");
//			CDTO.setFullName(567891234);
//			CDTO.setPhoneNumber("+9474052945");
//			CDTO.setEmailAddress("cliente@gmail.com");
//			PDTO.setClientDTO(CDTO); 
			
			Project updatedProject=new ModelMapper().map(PDTO, Project.class);
//			Client newClient=new ModelMapper().map(CDTO, Client.class);
			updatedProject.setClient(C);
	
			when(projectRepository.save(P)).thenReturn(updatedProject);
			projectServiceImpl.updateProject(PDTO);
			assertTrue(false);
			}catch(Exception e) {
			//	System.out.println(e);
				assertTrue(true);
			}
	}
	
	@Test
	public void testGetAllProjectsPositiveOneProjectFound() {
		try {
		Iterable<Project> iterableProjectMock=mock(Iterable.class);
		when(projectRepository.findAll()).thenReturn(iterableProjectMock);
		Iterator<Project> iteratorProjectMock=mock(Iterator.class);
		
		when(iterableProjectMock.iterator()).thenReturn(iteratorProjectMock);
		when(iteratorProjectMock.hasNext()).thenReturn(true).thenReturn(false);
		
		Project projectMock=mock(Project.class);
		
		when(iteratorProjectMock.next()).thenReturn(projectMock);
		when(projectMock.getProjectCode()).thenReturn(3);
		when(projectMock.getTitle()).thenReturn("Proj C");
		when(projectMock.getBudget()).thenReturn(20000);
		when(projectMock.getStartDate()).thenReturn(new Date(2024,2,10));
		when(projectMock.getExpectedEndDate()).thenReturn(new Date(2024,5,1));
		when(projectMock.getCreatedOn()).thenReturn(new Date(2024,1,10));
		when(projectMock.getStatus()).thenReturn("Completed");
		when(projectMock.getLastUpdatedOn()).thenReturn(new Date(2024,2,10));
		
		Client clientMock=mock(Client.class);
		
		when(projectMock.getClient()).thenReturn(clientMock);
		when(projectMock.getClient().getId()).thenReturn(3);
				
		List<ProjectDTO> PDTOList=projectServiceImpl.getAllProjects();
		assertTrue(PDTOList.size()==1);
		}catch(Exception e) {
//			System.out.println(e);
//			e.printStackTrace();
			assertTrue(false);
		} 
	} 
	
	@Test
	public void testGetAllProjectsPositiveMultipleProjectsFound() {
		try {
		Iterable<Project> iterableProjectMock=mock(Iterable.class);
		when(projectRepository.findAll()).thenReturn(iterableProjectMock);
		Iterator<Project> iteratorProjectMock=mock(Iterator.class);
		
		when(iterableProjectMock.iterator()).thenReturn(iteratorProjectMock);
		when(iteratorProjectMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);
		
		Project projectMock=mock(Project.class);
		
		when(iteratorProjectMock.next()).thenReturn(projectMock);
		when(projectMock.getProjectCode()).thenReturn(3);
		when(projectMock.getTitle()).thenReturn("Proj C");
		when(projectMock.getBudget()).thenReturn(20000);
		when(projectMock.getStartDate()).thenReturn(new Date(2024,2,10));
		when(projectMock.getExpectedEndDate()).thenReturn(new Date(2024,5,1));
		when(projectMock.getCreatedOn()).thenReturn(new Date(2024,1,10));
		when(projectMock.getStatus()).thenReturn("Completed");
		when(projectMock.getLastUpdatedOn()).thenReturn(new Date(2024,2,10));
		
		Client clientMock=mock(Client.class);
		
		when(projectMock.getClient()).thenReturn(clientMock);
		when(projectMock.getClient().getId()).thenReturn(3);
		
		List<ProjectDTO> PDTOList=projectServiceImpl.getAllProjects();
		assertTrue(PDTOList.size()>1);
		}catch(Exception e) {
		//	System.out.println(e);
			assertTrue(false);
		} 
	} 
	
	@Test
	public void testGetAllProjectsException() {
		try {
		Iterable<Project> iterableProjectMock=mock(Iterable.class);
		when(projectRepository.findAll()).thenReturn(iterableProjectMock);
		Iterator<Project> iteratorProjectMock=mock(Iterator.class);
		
		when(iterableProjectMock.iterator()).thenReturn(iteratorProjectMock);
		when(iteratorProjectMock.hasNext()).thenReturn(false);
		
		Project projectMock=mock(Project.class);
		
		when(iteratorProjectMock.next()).thenReturn(projectMock);
		when(projectMock.getProjectCode()).thenReturn(3);
		when(projectMock.getTitle()).thenReturn("Proj C");
		when(projectMock.getBudget()).thenReturn(20000);
		when(projectMock.getStartDate()).thenReturn(new Date(2024,2,10));
		when(projectMock.getExpectedEndDate()).thenReturn(new Date(2024,5,1));
		when(projectMock.getCreatedOn()).thenReturn(new Date(2024,1,10));
		when(projectMock.getStatus()).thenReturn("Completed");
		when(projectMock.getLastUpdatedOn()).thenReturn(new Date(2024,2,10));Client clientMock=mock(Client.class);
		
		when(projectMock.getClient()).thenReturn(clientMock);
		when(projectMock.getClient().getId()).thenReturn(3);
		
		
		when(projectMock.getClient().getId()).thenReturn(3);		

		List<ProjectDTO> PDTOList=projectServiceImpl.getAllProjects();
		assertTrue(false);
		}catch(Exception e) {
		//	System.out.println(e);
			assertTrue(true);
		} 
	}
}
