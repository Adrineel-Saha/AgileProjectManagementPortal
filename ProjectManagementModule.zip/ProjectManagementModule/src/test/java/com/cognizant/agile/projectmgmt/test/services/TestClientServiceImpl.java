package com.cognizant.agile.projectmgmt.test.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.*;
import org.mockito.*;

import com.cognizant.agile.projectmgmt.dto.ClientDTO;
import com.cognizant.agile.projectmgmt.entities.Client;
import com.cognizant.agile.projectmgmt.repositories.ClientRepository;
import com.cognizant.agile.projectmgmt.services.ClientServiceImpl;

public class TestClientServiceImpl {
	@Mock
	private ClientRepository clientRepository;
	@InjectMocks
	private ClientServiceImpl clientServiceImpl;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

	@Test
	public void testGetAllClientsPositiveOneClientFound() {
		try {
		Iterable<Client> iterableClientMock=mock(Iterable.class);
		when(clientRepository.findAll()).thenReturn(iterableClientMock);
		Iterator<Client> iteratorClientMock=mock(Iterator.class);
		
		when(iterableClientMock.iterator()).thenReturn(iteratorClientMock);
		when(iteratorClientMock.hasNext()).thenReturn(true).thenReturn(false);
		
		Client clientMock=mock(Client.class);
		
		when(iteratorClientMock.next()).thenReturn(clientMock);
		when(clientMock.getId()).thenReturn(1);
		when(clientMock.getName()).thenReturn("Client A");
		when(clientMock.getFullName()).thenReturn(123456789);
		when(clientMock.getPhoneNumber()).thenReturn("+9475612033");
		when(clientMock.getEmailAddress()).thenReturn("clienta@gmail.com");
		
		List<ClientDTO> CDTOList=clientServiceImpl.getAllClients();
		assertTrue(CDTOList.size()==1);
		}catch(Exception e) {
		//	System.out.println(e);
			assertTrue(false);
		} 
	}
	
	@Test
	public void testGetAllClientsPositiveMultipleClientsFound() {
		try {
		Iterable<Client> iterableClientMock=mock(Iterable.class);
		when(clientRepository.findAll()).thenReturn(iterableClientMock);
		Iterator<Client> iteratorClientMock=mock(Iterator.class);
		
		when(iterableClientMock.iterator()).thenReturn(iteratorClientMock);
		when(iteratorClientMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);
		
		Client clientMock=mock(Client.class);
		
		when(iteratorClientMock.next()).thenReturn(clientMock);
		when(clientMock.getId()).thenReturn(3);
		when(clientMock.getName()).thenReturn("Client C");
		when(clientMock.getFullName()).thenReturn(345678912);
		when(clientMock.getPhoneNumber()).thenReturn("+8515082009");
		when(clientMock.getEmailAddress()).thenReturn("clientc@gmail.com");
		
		List<ClientDTO> CDTOList=clientServiceImpl.getAllClients();
		assertTrue(CDTOList.size()>1);
		}catch(Exception e) {
		//	System.out.println(e);
			assertTrue(false);
		} 
	}
	
	@Test
	public void testGetAllClientsException() {
		try {
		Iterable<Client> iterableClientMock=mock(Iterable.class);
		when(clientRepository.findAll()).thenReturn(iterableClientMock);
		Iterator<Client> iteratorClientMock=mock(Iterator.class);
		
		when(iterableClientMock.iterator()).thenReturn(iteratorClientMock);
		when(iteratorClientMock.hasNext()).thenReturn(false);
		
		Client clientMock=mock(Client.class);
		
		when(iteratorClientMock.next()).thenReturn(clientMock);
		when(clientMock.getId()).thenReturn(2);
		when(clientMock.getName()).thenReturn("Client B");
		when(clientMock.getFullName()).thenReturn(234567891);
		when(clientMock.getPhoneNumber()).thenReturn("+9126320170");
		when(clientMock.getEmailAddress()).thenReturn("clientb@gmail.com");
		
		List<ClientDTO> CDTOList=clientServiceImpl.getAllClients();
		assertTrue(false);
		}catch(Exception e) {
		//	System.out.println(e);
			assertTrue(true);
		} 
	}
}
