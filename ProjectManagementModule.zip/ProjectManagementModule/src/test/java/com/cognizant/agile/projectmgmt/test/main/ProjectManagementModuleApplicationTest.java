package com.cognizant.agile.projectmgmt.test.main;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.agile.projectmgmt.controllers.ProjectManagementController;
import com.cognizant.agile.projectmgmt.main.ProjectManagementModuleApplication;

@SpringBootTest(classes=ProjectManagementModuleApplication.class)
public class ProjectManagementModuleApplicationTest {
	@Autowired
	private ProjectManagementController projectManagementController;
	
	@Test
	public void contextLoads() {
		assertNotNull(projectManagementController);
	}
}
