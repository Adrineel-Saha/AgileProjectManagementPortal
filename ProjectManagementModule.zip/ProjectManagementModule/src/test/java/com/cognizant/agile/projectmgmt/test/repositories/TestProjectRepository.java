package com.cognizant.agile.projectmgmt.test.repositories;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.agile.projectmgmt.entities.*;
import com.cognizant.agile.projectmgmt.main.ProjectManagementModuleApplication;
import com.cognizant.agile.projectmgmt.repositories.ProjectRepository;

@DataJpaTest
@ContextConfiguration(classes = ProjectManagementModuleApplication.class)
public class TestProjectRepository {
	@Autowired
	private ProjectRepository projectRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllPositive() {
		Project P=new Project();
		P.setProjectCode(1);
		P.setTitle("Proj A");
		P.setBudget(10000);
		P.setStartDate(new Date(2024,2,1));
		P.setExpectedEndDate(new Date(2024,3,15));
		P.setCreatedOn(new Date(2024,1,1));
		P.setStatus("New");
		P.setLastUpdatedOn(new Date(2024,2,1));
	
		Client C=new Client();
		C.setId(5);
		C.setName("Client E");
		C.setFullName(567891234);
		C.setPhoneNumber("+9474052945");
		C.setEmailAddress("cliente@gmail.com");
		entityManager.persist(C);
		P.setClient(C);
		entityManager.persist(P);
		Iterable<Project> it=projectRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegative() {
		Iterable<Project> it=projectRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		Project P=new Project();
		P.setProjectCode(2);
		P.setTitle("Proj B");
		P.setBudget(15000);
		P.setStartDate(new Date(2024,2,5));
		P.setExpectedEndDate(new Date(2024,4,20));
		P.setCreatedOn(new Date(2024,1,5));
		P.setStatus("InProgtess");
		P.setLastUpdatedOn(new Date(2024,2,5));
		
		Client C=new Client();
		C.setId(4);
		C.setName("Client D");
		C.setFullName(456789123);
		C.setPhoneNumber("+9433663287");
		C.setEmailAddress("clientd@gmail.com");
		entityManager.persist(C);
		P.setClient(C);
		entityManager.persist(P);
		Optional<Project> project=projectRepository.findById(2);
		assertTrue(project.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Project> project=projectRepository.findById(2);
		assertTrue(!project.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		Project P=new Project();
		P.setProjectCode(3);
		P.setTitle("Proj C");
		P.setBudget(20000);
		P.setStartDate(new Date(2024,2,10));
		P.setExpectedEndDate(new Date(2024,5,1));
		P.setCreatedOn(new Date(2024,1,10));
		P.setStatus("Completed");
		P.setLastUpdatedOn(new Date(2024,2,10));
	
		Client C=new Client();
		C.setId(3);
		C.setName("Client C");
		C.setFullName(345678912);
		C.setPhoneNumber("+8515082009");
		C.setEmailAddress("clientc@gmail.com");
		entityManager.persist(C);
		P.setClient(C);
		projectRepository.save(P);
		Optional<Project> project=projectRepository.findById(3);
		assertTrue(project.isPresent());
	}
	
	@Test
	public void testSaveNegative() {
		Optional<Project> project=projectRepository.findById(3);
		assertTrue(!project.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		Project P=new Project();
		P.setProjectCode(4);
		P.setTitle("Proj D");
		P.setBudget(25000);
		P.setStartDate(new Date(2024,2,15));
		P.setExpectedEndDate(new Date(2024,6,15));
		P.setCreatedOn(new Date(2024,1,15));
		P.setStatus("Delayed");
		P.setLastUpdatedOn(new Date(2024,2,15));
	
		Client C=new Client();
		C.setId(2);
		C.setName("Client B");
		C.setFullName(234567891);
		C.setPhoneNumber("+9126320710");
		C.setEmailAddress("clientb@gmail.com");
		entityManager.persist(C);
		P.setClient(C);
		entityManager.persist(P);
		projectRepository.delete(P);
		Optional<Project> project=projectRepository.findById(4);
		assertTrue(!project.isPresent());
	}
	
	@Test
	public void testDeleteNegative() {
		Optional<Project> project=projectRepository.findById(4);
		assertTrue(!project.isPresent());
	}
}
