package com.cognizant.agile.projectmgmt.test.repositories;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.agile.projectmgmt.entities.Client;
import com.cognizant.agile.projectmgmt.main.ProjectManagementModuleApplication;
import com.cognizant.agile.projectmgmt.repositories.ClientRepository;

@DataJpaTest
@ContextConfiguration(classes = ProjectManagementModuleApplication.class)
public class TestClientRepository {
	@Autowired
	private ClientRepository clientRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllPositive() {
		Client C=new Client();
		C.setId(1);
		C.setName("Client A");
		C.setFullName(123456789);
		C.setPhoneNumber("+9475612033");
		C.setEmailAddress("clienta@gmail.com");
		entityManager.persist(C);
		Iterable<Client> it=clientRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegative() {
		Iterable<Client> it=clientRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		Client C=new Client();
		C.setId(2);
		C.setName("Client B");
		C.setFullName(234567891);
		C.setPhoneNumber("+91263201710");
		C.setEmailAddress("clientb@gmail.com");
		entityManager.persist(C);
		Optional<Client> client=clientRepository.findById(2);
		assertTrue(client.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Client> client=clientRepository.findById(2);
		assertTrue(!client.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		Client C=new Client();
		C.setId(3);
		C.setName("Client C");
		C.setFullName(345678912);
		C.setPhoneNumber("+8515082009");
		C.setEmailAddress("clientc@gmail.com");
		clientRepository.save(C);
		Optional<Client> client=clientRepository.findById(3);
		assertTrue(client.isPresent());
	}
	
	@Test
	public void testSaveNegative() {
		Optional<Client> client=clientRepository.findById(3);
		assertTrue(!client.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		Client C=new Client();
		C.setId(4);
		C.setName("Client D");
		C.setFullName(456789123);
		C.setPhoneNumber("+9433663287");
		C.setEmailAddress("clientd@gmail.com");
		entityManager.persist(C);
		clientRepository.delete(C);
		Optional<Client> client=clientRepository.findById(4);
		assertTrue(!client.isPresent());
	}
	
	@Test
	public void testDeleteNegative() {
		Optional<Client> client=clientRepository.findById(4);
		assertTrue(!client.isPresent());
	}
}
