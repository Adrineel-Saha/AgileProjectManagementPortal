package com.cognizant.agile.projectmgmt.test.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.*;
import org.mockito.*;
import org.modelmapper.ModelMapper;

import com.cognizant.agile.projectmgmt.dto.*;
import com.cognizant.agile.projectmgmt.entities.*;
import com.cognizant.agile.projectmgmt.exceptions.MaximumResourceLimitReachedException;
import com.cognizant.agile.projectmgmt.repositories.*;
import com.cognizant.agile.projectmgmt.services.ResourceServiceImpl;


public class TestResourceServiceImpl {
	@Mock
	private ResourceRepository resourceRepository;
	@Mock
	private ProjectRepository projectRepository;
	@InjectMocks
	private ResourceServiceImpl resourceServiceImpl;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@AfterEach
	void tearDown() throws Exception {
		
	} 

	@Test
	public void testAddResourcePositive() {
	try {
		ResourceDTO RDTO=new ResourceDTO();
		RDTO.setUserId("User 2");
		RDTO.setFirstName("Yash");
		RDTO.setLastName("Biswakarma");
		RDTO.setEmail("biswakarmayash@cognizant.com");
		RDTO.setPhoneNumber("+876902341");
		RDTO.setRole("Tester");
		RDTO.setProjectCode(4);
		
		Project P=new Project();
		P.setProjectCode(4);
		P.setTitle("Proj D");
		P.setBudget(25000);
		P.setStartDate(new Date(2024,2,15));
		P.setExpectedEndDate(new Date(2024,6,15));
		P.setCreatedOn(new Date(2024,1,15));
		P.setStatus("Delayed");
		P.setLastUpdatedOn(new Date(2024,2,15));
		
		Client C=new Client();
		C.setId(2);
		C.setName("Client B");
		C.setFullName(234567891);
		C.setPhoneNumber("+9126320710");
		C.setEmailAddress("clientb@gmail.com");
		
		P.setClient(C);
//		RDTO.setProjectDTO(PDTO);
		
		when(projectRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(P));
		Resource resourceMock=new ModelMapper().map(RDTO,Resource.class);
//		Project projectMock=new ModelMapper().map(PDTO,Project.class);
//		Client clientMock=new ModelMapper().map(CDTO, Client.class);
		
//		projectMock.setClient(clientMock);
		resourceMock.setProject(P);
		
		when(resourceRepository.save(Mockito.any())).thenReturn(resourceMock);
		ResourceDTO actualRDTO=resourceServiceImpl.addResource(RDTO);
		assertNotEquals(null,actualRDTO);
	}catch(Exception e) {
		//e.printStackTrace();
	//	System.out.println(e);
		assertTrue(false);
		}
	} 
	
	@Test
	public void testAddResourceNegative() {
	try {
		ResourceDTO RDTO=new ResourceDTO();
		RDTO.setUserId("User 1");
		RDTO.setFirstName("Adrineel");
		RDTO.setLastName("Saha");
		RDTO.setEmail("adrineelsaha@cognizant.com");
		RDTO.setPhoneNumber("+93849234");
		RDTO.setRole("DeveloperTester");
	
		Project P=new Project();
		P.setProjectCode(3);
		P.setTitle("Proj C");
		P.setBudget(20000);
		P.setStartDate(new Date(2024,2,10));
		P.setExpectedEndDate(new Date(2024,5,1));
		P.setCreatedOn(new Date(2024,1,10));
		P.setStatus("InProgress");
		P.setLastUpdatedOn(new Date(2024,2,10));

		Client C=new Client();
		C.setId(3);
		C.setName("Client C");
		C.setFullName(345678912);
		C.setPhoneNumber("+8515082009");
		C.setEmailAddress("clientc@gmail.com");
		
		P.setClient(C);
//		RDTO.setProjectDTO(PDTO);
		
		when(projectRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(P));
		Resource resourceMock=new ModelMapper().map(RDTO,Resource.class);
//		Project projectMock=new ModelMapper().map(PDTO,Project.class);
//		Client clientMock=new ModelMapper().map(CDTO, Client.class);
		
//		projectMock.setClient(clientMock);
		resourceMock.setProject(P);
		
		when(resourceRepository.save(Mockito.any())).thenReturn(resourceMock);
		resourceServiceImpl.addResource(RDTO);
		assertTrue(false);
	}catch(Exception e) {
		//e.printStackTrace();
	//	System.out.println(e);
		assertTrue(true);
		}
	} 
	
	@Test
	public void testAddResourceException() {
	try {
		ResourceDTO RDTO=new ResourceDTO();
		RDTO.setUserId("User 4");
		RDTO.setFirstName("Tahleel");
		RDTO.setLastName("Shah");
		RDTO.setEmail("shahtahleel@cognizant.com");
		RDTO.setPhoneNumber("+902183746");
		RDTO.setRole("Tester");
	
		Project P=new Project();
		P.setProjectCode(1);
		P.setTitle("Proj A");
		P.setBudget(10000);
		P.setStartDate(new Date(2024,2,1));
		P.setExpectedEndDate(new Date(2024,3,15));
		P.setCreatedOn(new Date(2024,1,1));
		P.setStatus("Completed");
		P.setLastUpdatedOn(new Date(2024,2,1));
		
		Client C=new Client();
		C.setId(5);
		C.setName("Client E");
		C.setFullName(567891234);
		C.setPhoneNumber("+9474052945");
		C.setEmailAddress("cliente@gmail.com");
		
		P.setClient(C);
//		RDTO.setProjectDTO(PDTO);
		
		when(projectRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(P));
		Resource resourceMock=new ModelMapper().map(RDTO,Resource.class);
//		Project projectMock=new ModelMapper().map(PDTO,Project.class);
//		Client clientMock=new ModelMapper().map(CDTO, Client.class);
		
//		projectMock.setClient(clientMock);
		resourceMock.setProject(P);
		
		when(resourceRepository.save(Mockito.any())).thenThrow(new MaximumResourceLimitReachedException("Maximum 10 testers are allowed"));
		resourceServiceImpl.addResource(RDTO);
		assertTrue(false);
	}catch(Exception e) {
		//e.printStackTrace();
	//	System.out.println(e);
		assertTrue(true);
		}
	} 
}

