package com.cognizant.agile.projectmgmt.test.repositories;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.agile.projectmgmt.entities.*;
import com.cognizant.agile.projectmgmt.main.ProjectManagementModuleApplication;
import com.cognizant.agile.projectmgmt.repositories.ResourceRepository;

@DataJpaTest
@ContextConfiguration(classes = ProjectManagementModuleApplication.class)
public class TestResourceRepository {
	@Autowired
	private ResourceRepository resourceRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllPositive() {
		Resource R=new Resource();
		R.setUserId("User 1");
		R.setFirstName("Adrineel");
		R.setLastName("Saha");
		R.setEmail("adrineelsaha@gmail.com");
		R.setPhoneNumber("+938492345");
		R.setRole("Developer");
	
		Project P=new Project();
		P.setProjectCode(3);
		P.setTitle("Proj C");
		P.setBudget(20000);
		P.setStartDate(new Date(2024,2,10));
		P.setExpectedEndDate(new Date(2024,5,1));
		P.setCreatedOn(new Date(2024,1,10));
		P.setStatus("Completed");
		P.setLastUpdatedOn(new Date(2024,2,10));
		entityManager.persist(P);
		R.setProject(P);
		entityManager.persist(R);
		Iterable<Resource> it=resourceRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegative() {
		Iterable<Resource> it=resourceRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		Resource R=new Resource();
		R.setUserId("User 2");
		R.setFirstName("Yash");
		R.setLastName("Biswakarma");
		R.setEmail("biswakarmayash@gmail.com");
		R.setPhoneNumber("+876902341");
		R.setRole("Tester");
	
		Project P=new Project();
		P.setProjectCode(4);
		P.setTitle("Proj D");
		P.setBudget(25000);
		P.setStartDate(new Date(2024,2,15));
		P.setExpectedEndDate(new Date(2024,6,15));
		P.setCreatedOn(new Date(2024,1,15));
		P.setStatus("Delayed");
		P.setLastUpdatedOn(new Date(2024,2,15));
		entityManager.persist(P);
		R.setProject(P);
		entityManager.persist(R);
		Optional<Resource> resource=resourceRepository.findById("User 2");
		assertTrue(resource.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Resource> resource=resourceRepository.findById("User 2");
		assertTrue(!resource.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		Resource R=new Resource();
		R.setUserId("User 3");
		R.setFirstName("Krishnendu");
		R.setLastName("Ghosh");
		R.setEmail("krishghosh@gmail.com");
		R.setPhoneNumber("+953467213");
		R.setRole("Developer");
	
		Project P=new Project();
		P.setProjectCode(5);
		P.setTitle("Proj D");
		P.setBudget(30000);
		P.setStartDate(new Date(2024,2,20));
		P.setExpectedEndDate(new Date(2024,7,1));
		P.setCreatedOn(new Date(2024,1,20));
		P.setStatus("Cancelled");
		P.setLastUpdatedOn(new Date(2024,2,20));
		entityManager.persist(P);
		R.setProject(P);
		resourceRepository.save(R);
		Optional<Resource> resource=resourceRepository.findById("User 3");
		assertTrue(resource.isPresent());
	}
	
	@Test
	public void testSaveNegative() {
		Optional<Resource> resource=resourceRepository.findById("User 3");
		assertTrue(!resource.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		Resource R=new Resource();
		R.setUserId("User 4");
		R.setFirstName("Tahleel");
		R.setLastName("Shah");
		R.setEmail("shahtahleel@gmail.com");
		R.setPhoneNumber("+902183746");
		R.setRole("Tester");
	
		Project P=new Project();
		P.setProjectCode(1);
		P.setTitle("Proj A");
		P.setBudget(10000);
		P.setStartDate(new Date(2024,2,1));
		P.setExpectedEndDate(new Date(2024,3,15));
		P.setCreatedOn(new Date(2024,1,1));
		P.setStatus("New");
		P.setLastUpdatedOn(new Date(2024,2,1));
		entityManager.persist(P);
		R.setProject(P);
		entityManager.persist(R);
		resourceRepository.delete(R);
		Optional<Resource> resource=resourceRepository.findById("User 4");
		assertTrue(!resource.isPresent());
	}
	
	@Test
	public void testDeleteNegative() {
		Optional<Resource> resource=resourceRepository.findById("User 4");
		assertTrue(!resource.isPresent());
	}
}