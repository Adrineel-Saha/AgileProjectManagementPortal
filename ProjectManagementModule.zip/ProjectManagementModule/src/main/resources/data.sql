Insert into Clients (Id, Name, POC_Full_Name, POC_Phone_Number, POC_Email_Address) Values
(1,'Client A',123456789,'+9475612033','clienta@cognizant.com'),
(2,'Client B',234567891,'+9126320710','clientb@cognizant.com'),
(3,'Client C',345678912,'+8515082009','clientc@cognizant.com'),
(4,'Client D',456789123,'+9433663287','clientd@cognizant.com'),
(5,'Client E',567891234,'+9474052945','cliente@cognizant.com');

Insert into Projects (Project_Code,Title,Budget,Start_Date,Expected_End_Date,Created_On,Status,Last_Updated_On,Client_Id) Values
(1,'Proj_A',10000,'2024-02-01','2024-03-15','2024-01-01','New','2024-02-01',5),
(2,'Proj_B',15000,'2024-02-05','2024-04-20','2024-01-05','InProgress','2024-02-05',4),
(3,'Proj_C',20000,'2024-02-10','2024-05-01','2024-01-10','Completed','2024-02-10',3),
(4,'Proj_D',25000,'2024-02-15','2024-06-15','2024-01-15','Delayed','2024-02-15',2),
(5,'Proj_E',30000,'2024-02-20','2024-07-01','2024-01-20','Cancelled','2024-02-20',1);

Insert into Resources (User_Id,First_Name,Last_Name,Email,Phone_Number,Role,Project_Code) Values
('User_1','Adrineel','Saha','adrineelsaha@cognizant.com','+938492345','Developer',3),
('User_2','Yash','Biswakarma','biswakarmayash@cognizant.com','+876902341','Tester',4),
('User_3','Krishnendu','Ghosh','krishghosh@cognizants.com','+953467213','Developer',5),
('User_4','Tahleel','Shah','shahtahleel@cognizant.com','+902183746','Tester',1),
('User_5','Akash','Patil','akashpatil@cognizant.com','+978654312','Developer',2);

insert into Users (User_Name,Password,Role,Is_Account_Locked) Values
('Adrineel','Adri@2001','Product Owner',false),
('Ayan','Ayan#1704','Client',false),
('Ashish','Ashish#1803','Product Owner',false),
('Rakesh','Rakesh@2000','Client',false),
('Sagar','Sagar#2902','Product Owner',false);
