Create table Clients(Id integer, Name varchar(50), POC_Full_Name integer, POC_Phone_Number varchar(16),
POC_Email_Address varchar(100), Constraint PK1 Primary Key(Id));

Create table Projects(Project_Code integer, Title varchar(50) Check(Length(Title)>=3), 
Budget integer, Start_Date date, Expected_End_Date date,Created_On date,
Status varchar(20) Check(Status In ('New','InProgress','Completed','Delayed','Cancelled')), 
Last_Updated_On date, Client_Id integer,Constraint CHK1  Check(Expected_End_Date>Start_Date),
Constraint PK2 Primary Key(Project_Code), Constraint FK2 Foreign Key (Client_Id)
References Clients(Id));

Create table Resources(User_Id varchar(6) Check(Length(User_Id)=6), First_Name varchar(15) Check(Length(First_Name)>=3),
Last_Name varchar(15) Check(Length(Last_Name)>=3), Email varchar(50), Phone_Number varchar(10), 
Role varchar(20) Check(Role In ('Developer','Tester')),Project_Code integer,
Constraint PK3 Primary Key(User_Id), Constraint FK3 Foreign Key (Project_Code) References Projects(Project_Code));

Create table Users(User_Name varchar(40),Password varchar(40) not null,Role varchar(40) not null,Is_Account_Locked boolean);