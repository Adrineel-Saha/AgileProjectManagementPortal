package com.cognizant.agile.projectmgmt.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.cognizant.agile.projectmgmt.dto.UserDTO;
import com.cognizant.agile.projectmgmt.dto.UserRequestDTO;
import com.cognizant.agile.projectmgmt.services.UserService;

@RestController
@RequestMapping("authenticate")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthenticationController { 
	@Autowired
	private UserService userService;
	
	@PostMapping("users")
	public ResponseEntity<?> authenticate(@RequestBody UserRequestDTO userRequestDTO){
		UserDTO userDTO=userService.authenticateUser(userRequestDTO.getUserName(), userRequestDTO.getPassword());
		if(userDTO.getUserName()!=null) {
			return new ResponseEntity<UserDTO>(userDTO,HttpStatus.ACCEPTED);
		}else {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}	
	}	
}