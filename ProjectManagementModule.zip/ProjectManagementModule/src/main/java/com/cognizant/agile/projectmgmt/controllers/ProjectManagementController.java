package com.cognizant.agile.projectmgmt.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.cognizant.agile.projectmgmt.dto.*;
import com.cognizant.agile.projectmgmt.services.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j 
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("api")
@Tag(name="ProjectManagement",description = "ProjectManagement REST API")
public class ProjectManagementController {
	@Autowired  
	ClientService clientService;
	
	@Autowired
	ProjectService projectService;
	
	@Autowired
	ResourceService resourceService;
	
	@GetMapping("clients")
	@Operation(summary="Get all Clients",description="Retrieve a list of all clients")
	public ResponseEntity<?> getAllClients() {
		log.info("Getting all Clients");
		
		List<ClientDTO> CDTOList=clientService.getAllClients(); 
		ResponseEntity<List<ClientDTO>> responseEntity=null;
		if(!CDTOList.isEmpty()){
			responseEntity=new ResponseEntity<List<ClientDTO>>(CDTOList, HttpStatus.OK);
		}
		else{
			responseEntity=new ResponseEntity<> (HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@PostMapping("projects/new") 
	@Operation(summary="Create a Project",description="Creates a new project")
	public ResponseEntity<?> addProject(@RequestBody ProjectDTO PDTO){
		log.info("Adding a new project: " + PDTO); 
		
		ProjectDTO newPDTO=projectService.addProject(PDTO);
		if (newPDTO!=null){
			return new ResponseEntity<>(HttpStatus.CREATED);
		}
		else{
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("projects")
	@Operation(summary="Get all Projects",description="Retrieve a list of all projects")
	public ResponseEntity<?> getAllProjects(){
		log.info("Getting all Projects");
		
		List<ProjectDTO> PDTOList=projectService.getAllProjects(); 
		ResponseEntity<List<ProjectDTO>> responseEntity=null;
		if(!PDTOList.isEmpty()){
			responseEntity=new ResponseEntity<List<ProjectDTO>>(PDTOList,HttpStatus.OK);
		} 
		else{
			responseEntity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@PutMapping("projects/{projectCode}/update")
	@Operation(summary="Update a Project",description="Updates an existing project")
	public ResponseEntity<?> updateProject(@PathVariable("projectCode") int projectCode,@RequestBody ProjectDTO PDTO){
		log.info("Updating project " + PDTO + " with procectCode: " + projectCode);
		ProjectDTO newPDTO=projectService.updateProject(PDTO);
		System.out.println(newPDTO);

		if(newPDTO!=null) {
			return new ResponseEntity<>(HttpStatus.ACCEPTED);
		}
		else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("projects/addresource") 
	@Operation(summary="Create a Resource",description="Creates a new resource")
	public ResponseEntity<?> addResource(@RequestBody ResourceDTO RDTO){ 
		log.info("Adding a new resource: " + RDTO);
		
		ResourceDTO newRDTO=resourceService.addResource(RDTO);
		if(newRDTO!=null) {
			return new ResponseEntity<String>(newRDTO.getUserId(),HttpStatus.CREATED); 
		}
		else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
}
