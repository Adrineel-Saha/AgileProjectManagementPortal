package com.cognizant.agile.projectmgmt.services;

import java.util.List;

import com.cognizant.agile.projectmgmt.dto.ClientDTO;

public interface ClientService {
	public List<ClientDTO> getAllClients();
}
