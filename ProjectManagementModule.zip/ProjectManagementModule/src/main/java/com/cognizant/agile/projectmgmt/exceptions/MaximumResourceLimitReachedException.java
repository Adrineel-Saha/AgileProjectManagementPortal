package com.cognizant.agile.projectmgmt.exceptions;

public class MaximumResourceLimitReachedException extends RuntimeException {

	public MaximumResourceLimitReachedException(String message) {
		super(message);
	}
	
}
