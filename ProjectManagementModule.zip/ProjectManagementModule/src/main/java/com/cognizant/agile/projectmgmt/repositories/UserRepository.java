package com.cognizant.agile.projectmgmt.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.agile.projectmgmt.entities.Users;

@Repository
public interface UserRepository extends CrudRepository<Users,String>{
	
}
