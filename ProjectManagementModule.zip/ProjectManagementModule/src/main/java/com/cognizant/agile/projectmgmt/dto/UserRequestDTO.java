package com.cognizant.agile.projectmgmt.dto;

import lombok.Data;

@Data
public class UserRequestDTO {
	private String userName;

	private String password;
}
