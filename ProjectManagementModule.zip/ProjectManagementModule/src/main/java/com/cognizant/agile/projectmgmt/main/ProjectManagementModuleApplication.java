package com.cognizant.agile.projectmgmt.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.cognizant.agile.projectmgmt.*")
@EnableJpaRepositories(basePackages = "com.cognizant.agile.projectmgmt.repositories")
@EntityScan(basePackages = "com.cognizant.agile.projectmgmt.entities")
@EnableDiscoveryClient(autoRegister=true)
public class ProjectManagementModuleApplication {
	public static void main(String[] args) {
		SpringApplication.run(ProjectManagementModuleApplication.class, args);
	}
}
