package com.cognizant.agile.projectmgmt.entities;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name="Users")
public class Users {
	@Id
	@Column(name="User_Name")
	private String userName;
	
	@Column(name="Password")
	private String password;
	
	@Column(name="Role")
	private String role;
	
	@Column(name="Is_Account_Locked")
	private boolean isAccountLocked;
}
