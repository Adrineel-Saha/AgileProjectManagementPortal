package com.cognizant.agile.projectmgmt.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.agile.projectmgmt.entities.Project;
import com.cognizant.agile.projectmgmt.entities.Resource;

@Repository
public interface ResourceRepository extends CrudRepository<Resource,String>{
	int countByRoleAndProject(String role,Project P);
}
