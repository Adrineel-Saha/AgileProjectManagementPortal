package com.cognizant.agile.projectmgmt.utilities;

import java.util.Set;

import com.cognizant.agile.projectmgmt.dto.ProjectDTO;

import jakarta.validation.*;

public class ProjectValidation {
	public static void validateProject(ProjectDTO PDTO) {
		Validator validator=Validation.buildDefaultValidatorFactory().getValidator();
		Set<ConstraintViolation<ProjectDTO>> violations=validator.validate(PDTO);
		
		if(!violations.isEmpty()) {
			throw new ConstraintViolationException(violations);
		}
	}
}