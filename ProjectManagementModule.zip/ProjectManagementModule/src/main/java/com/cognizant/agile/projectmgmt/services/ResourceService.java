package com.cognizant.agile.projectmgmt.services;

import com.cognizant.agile.projectmgmt.dto.ResourceDTO;

public interface ResourceService {

	public ResourceDTO addResource(ResourceDTO RDTO);
	
//	public void validateResource(Resources R);
	
//	public String generateUserId(String lastName);
}
