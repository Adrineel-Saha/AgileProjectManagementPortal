package com.cognizant.agile.projectmgmt.utilities;

import java.util.Random;

public class UserIdGeneration {
	public static String generateUserId(String lastName) {
		String formattedLastName=lastName.substring(0,Math.min(2, lastName.length())).toUpperCase();
		int randomNumber=new Random().nextInt(9000)+1000;
		String formattedNumber=String.valueOf(randomNumber);
		return formattedLastName+formattedNumber;
	}
}
