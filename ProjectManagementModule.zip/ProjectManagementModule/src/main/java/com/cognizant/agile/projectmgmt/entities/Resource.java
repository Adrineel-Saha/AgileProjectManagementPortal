package com.cognizant.agile.projectmgmt.entities;

import jakarta.persistence.*;

import lombok.Data;

@Data
@Entity
@Table(name="Resources")
public class Resource {
	@Id
	@Column(name="User_Id")
	private String userId;
	
	@Column(name="First_Name")
	private String firstName;
	
	@Column(name="Last_Name")
	private String lastName;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Phone_Number")
	private String phoneNumber;
	
	@Column(name="Role")
	private String role;
	
	@ManyToOne
	@JoinColumn(name="Project_Code",referencedColumnName="Project_Code")
	private Project project;

}
