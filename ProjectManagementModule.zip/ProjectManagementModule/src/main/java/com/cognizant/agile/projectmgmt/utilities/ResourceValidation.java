package com.cognizant.agile.projectmgmt.utilities;

import java.util.*;

//import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.agile.projectmgmt.dto.*;
import com.cognizant.agile.projectmgmt.entities.*;
import com.cognizant.agile.projectmgmt.exceptions.MaximumResourceLimitReachedException;
import com.cognizant.agile.projectmgmt.repositories.*;

import jakarta.validation.*;

public  class ResourceValidation {
	private ResourceRepository resourceRepository;
	
	private ProjectRepository projectRepository;
	
//	private ClientRepository clientRepository;
	
//	private ModelMapper modelMapper=new ModelMapper();
	
	@Autowired
	public ResourceValidation(ResourceRepository resourceRepository,ProjectRepository projectRepository)
	{
		this.resourceRepository=resourceRepository;
		this.projectRepository=projectRepository;
//		this.clientRepository=clientRepository;
	}
	public void validateResource(ResourceDTO RDTO) {
		Validator validator=Validation.buildDefaultValidatorFactory().getValidator();
		Set<ConstraintViolation<ResourceDTO>> violations=validator.validate(RDTO);
		
		Optional<Project> POptional=projectRepository.findById(RDTO.getProjectCode());
		
		Project P=POptional.orElseThrow(()->new RuntimeException("Project not found with code: "+ RDTO.getProjectCode()));
		
//		Optional<Client> COptional=projectRepository.findById(RDTO.);
		
		if(!violations.isEmpty()) {
			throw new ConstraintViolationException(violations);
		}
		
		if(!RDTO.getFirstName().matches("[a-zA-Z]+") || !RDTO.getLastName().matches("[a-zA-Z]+")||
				RDTO.getFirstName().length()<3 || RDTO.getLastName().length()<3) {
			throw new IllegalArgumentException("Invalid first name or last name");
		}
		
		if(!RDTO.getEmail().endsWith("@cognizant.com")) {
			throw new IllegalArgumentException("Email address should always have @cognizant.com");
		}
		
		if(RDTO.getPhoneNumber().length()!=10) {
			throw new IllegalArgumentException("Phone number should be exactly 10 digits long");
		}
		
		if("Cancelled".equals(P.getStatus())) {
			throw new IllegalArgumentException("Cannot add resource to a cancelled project");
		}
		
		if("Developer".equals(RDTO.getRole())) {
			String role=RDTO.getRole();
//			ProjectDTO PDTO=RDTO.getProjectDTO();
//			ClientDTO CDTO=RDTO.getProjectDTO().getClientDTO();
//			
//			Project P=modelMapper.map(PDTO,Project.class);
//			Client C=modelMapper.map(CDTO,Client.class);
//			
//			P.setClient(C);
			
			if(resourceRepository.countByRoleAndProject(role,P)>50) {
				throw new MaximumResourceLimitReachedException("Maximum 50 developers are allowed");
			} 
		} 
		
		if("Tester".equals(RDTO.getRole())) {
			String role=RDTO.getRole();
//			ProjectDTO PDTO=RDTO.getProjectDTO();
//			ClientDTO CDTO=RDTO.getProjectDTO().getClientDTO();
//			
//			Project P=modelMapper.map(PDTO,Project.class);
//			Client C=modelMapper.map(CDTO,Client.class);
//			
//			P.setClient(C);
			
			if(resourceRepository.countByRoleAndProject(role,P)>10) {
				throw new MaximumResourceLimitReachedException("Maximum 10 testers are allowed");
			}
		}  
		
	} 
	
	
}





