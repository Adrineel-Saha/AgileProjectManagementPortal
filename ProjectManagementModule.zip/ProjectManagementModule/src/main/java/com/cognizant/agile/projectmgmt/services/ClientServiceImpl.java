package com.cognizant.agile.projectmgmt.services;

import java.util.*;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.agile.projectmgmt.dto.ClientDTO;
import com.cognizant.agile.projectmgmt.entities.Client;
import com.cognizant.agile.projectmgmt.repositories.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService{
	@Autowired
	private ClientRepository clientRepository;
	
	private ModelMapper modelMapper=new ModelMapper(); 
	

	@Override
	public List<ClientDTO> getAllClients(){
		Iterable<Client> CIterable=clientRepository.findAll();
		List<ClientDTO> CDTOList=new ArrayList<>();
		Iterator<Client> CIterator=CIterable.iterator();
		while(CIterator.hasNext()) {
			Client C=CIterator.next();
		/*	ClientDTO CDTO=new ClientDTO();
			CDTO.setId(C.getId());
			CDTO.setName(C.getName());
			CDTO.setFullName(C.getFullName());
			CDTO.setPhoneNumber(C.getPhoneNumber());
			CDTO.setEmailAddress(C.getEmailAddress());	*/
			ClientDTO CDTO=modelMapper.map(C, ClientDTO.class);
			CDTOList.add(CDTO);	
			
		}
		if(CDTOList.isEmpty()) {
			throw new RuntimeException("List is empty");
		}
		return CDTOList;
	} 
	
}
