package com.cognizant.agile.projectmgmt.services;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.agile.projectmgmt.dto.*;
import com.cognizant.agile.projectmgmt.entities.*;
import com.cognizant.agile.projectmgmt.repositories.*;
import com.cognizant.agile.projectmgmt.utilities.*;

@Service
public class ResourceServiceImpl implements ResourceService {
	@Autowired
	private ResourceRepository resourceRepository;
	
	@Autowired
	private ProjectRepository projectRepository;
	
	private ModelMapper modelMapper=new ModelMapper();
	
	@Override
	public ResourceDTO addResource(ResourceDTO RDTO) {
		ResourceValidation RValidation=new ResourceValidation(resourceRepository,projectRepository);
		RValidation.validateResource(RDTO);
//		ProjectValidation.validateProject(RDTO.getProjectDTO());
//		ClientValidation.validateClient(RDTO.getProjectDTO().getClientDTO());
		
		RDTO.setUserId(UserIdGeneration.generateUserId(RDTO.getLastName()));
		
		Optional<Project> POptional=projectRepository.findById(RDTO.getProjectCode());
		
		Project P=POptional.orElseThrow(()->new RuntimeException("Project not found with code: "+ RDTO.getProjectCode()));
		
		Resource R=modelMapper.map(RDTO, Resource.class);
//		Project P=modelMapper.map(RDTO.getProjectDTO(), Project.class);
//		Client C=modelMapper.map(RDTO.getProjectDTO().getClientDTO(), Client.class);
//		P.setClient(C);
		R.setProject(P);
		
		Resource createdResource=resourceRepository.save(R);
		
		ResourceDTO newRDTO=modelMapper.map(createdResource, ResourceDTO.class);
//		ProjectDTO newPDTO=modelMapper.map(createdResource.getProject(), ProjectDTO.class);
//		ClientDTO newCDTO=modelMapper.map(createdResource.getProject().getClient(), ClientDTO.class);
//		newPDTO.setClientDTO(newCDTO);
		newRDTO.setProjectCode(R.getProject().getProjectCode());
		
		return newRDTO;
	}
}

