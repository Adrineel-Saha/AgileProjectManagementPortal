package com.cognizant.agile.projectmgmt.dto;

import org.hibernate.validator.constraints.*;

import lombok.Data;

@Data
public class ClientDTO {
	private int id;
	
	@Length(max=50)
	private String name;
	
	private int fullName;
	
	@Length(max=16)
	private String phoneNumber;
	
	@Length(max=100)
	private String emailAddress;
	
}
