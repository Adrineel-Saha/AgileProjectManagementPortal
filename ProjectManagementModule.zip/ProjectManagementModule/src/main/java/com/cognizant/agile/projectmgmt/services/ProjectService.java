package com.cognizant.agile.projectmgmt.services;

import java.util.List;

import com.cognizant.agile.projectmgmt.dto.ProjectDTO;

public interface ProjectService {
	
	public ProjectDTO addProject(ProjectDTO PDTO);
	
//	public ProjectDTO updateProject(int projectCode,String newStatus);
	
	public ProjectDTO updateProject(ProjectDTO PDTO);
	
//	public void validateProject(Projects P);
	
	public List<ProjectDTO> getAllProjects();
}
