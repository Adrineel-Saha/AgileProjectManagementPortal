package com.cognizant.agile.projectmgmt.entities;

import jakarta.persistence.*;

import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name="Projects")
public class Project {
	@Id
	@Column(name="Project_Code")
	private int projectCode;
	
	@Column(name="Title")
	private String title;
	
	@Column(name="Budget")
	private int budget;
	
	@Column(name="Start_Date")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name="Expected_End_Date")
	@Temporal(TemporalType.DATE)
	private Date expectedEndDate;
	
	@Column(name="Created_On")
	@Temporal(TemporalType.DATE)
	private Date createdOn;
	
	@Column(name="Status")
	private String status;
	
	@Column(name="Last_Updated_On")
	@Temporal(TemporalType.DATE)
	private Date lastUpdatedOn;
	
	@ManyToOne
	@JoinColumn(name="Client_Id",referencedColumnName="Id")
	private Client client;

}
