package com.cognizant.agile.projectmgmt.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.agile.projectmgmt.entities.Project;

@Repository
public interface ProjectRepository extends CrudRepository<Project,Integer>{

}
