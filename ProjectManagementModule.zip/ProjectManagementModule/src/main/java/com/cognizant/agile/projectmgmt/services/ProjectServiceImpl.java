package com.cognizant.agile.projectmgmt.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.agile.projectmgmt.dto.*;
import com.cognizant.agile.projectmgmt.entities.*;
import com.cognizant.agile.projectmgmt.repositories.*;
import com.cognizant.agile.projectmgmt.utilities.*;

@Service
public class ProjectServiceImpl implements ProjectService {
	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ClientRepository clientRepository;
	
	private ModelMapper modelMapper=new ModelMapper();
	
	@Override
	public ProjectDTO addProject(ProjectDTO PDTO) {
		ProjectValidation.validateProject(PDTO);
//		ClientValidation.validateClient(PDTO.getClientDTO());
		
		Optional<Client> COptional=clientRepository.findById(PDTO.getClientId());
		Client C=COptional.orElseThrow(()->new RuntimeException("Client not found with code: "+ PDTO.getClientId()));
		
		Project P=modelMapper.map(PDTO, Project.class);
//		Client C=modelMapper.map(PDTO.getClientDTO(), Client.class);
		P.setClient(C);
		
		Project createdProject=projectRepository.save(P);
		
		ProjectDTO newPDTO=modelMapper.map(createdProject,ProjectDTO.class);
//		ClientDTO newCDTO=modelMapper.map(createdProject.getClient(), ClientDTO.class);
		newPDTO.setClientId(createdProject.getClient().getId());
		
		return newPDTO;
		
	}
	
	@Override
	public ProjectDTO updateProject(ProjectDTO PDTO) {
		ProjectValidation.validateProject(PDTO);
//		ClientValidation.validateClient(PDTO.getClientDTO());
		
		Optional<Project> POptional=projectRepository.findById(PDTO.getProjectCode());
		Project existingProject = POptional.orElseThrow(()->new RuntimeException("Project not found with code: "+ PDTO.getProjectCode()));
		
		existingProject.setStatus(PDTO.getStatus());
		
		Project updatedProject = projectRepository.save(existingProject);

		ProjectDTO newPDTO=modelMapper.map(updatedProject,ProjectDTO.class);
//		ClientDTO newCDTO=modelMapper.map(updatedProject.getClient(), ClientDTO.class);
		newPDTO.setClientId(updatedProject.getClient().getId());
		
		return newPDTO;
	}
	
	@Override
	public List<ProjectDTO> getAllProjects(){
		Iterable<Project> PIterable=projectRepository.findAll();
		List<ProjectDTO> PDTOList=new ArrayList<ProjectDTO>();
		Iterator<Project> PIterator=PIterable.iterator();
		
		while(PIterator.hasNext()) {
			Project P=PIterator.next();
		/*	ProjectDTO PDTO=new ProjectDTO();
			PDTO.setProjectCode(P.getProjectCode());
			PDTO.setTitle(P.getTitle());
			PDTO.setBudget(P.getBudget());
			PDTO.setStartDate(P.getStartDate());
			PDTO.setExpectedEndDate(P.getExpectedEndDate());
			PDTO.setCreatedOn(P.getCreatedOn());
			PDTO.setStatus(P.getStatus());
			PDTO.setLastUpdatedOn(P.getLastUpdatedOn());
			PDTO.setClient(P.getClient());	*/
			ProjectDTO PDTO=modelMapper.map(P,ProjectDTO.class);
//			ClientDTO CDTO=modelMapper.map(P.getClient(),ClientDTO.class);
			PDTO.setClientId(P.getClient().getId());
			
			PDTOList.add(PDTO);
		}
		
		if(PDTOList.isEmpty()) {
			throw new RuntimeException("List is empty");
		}
		return PDTOList;
	
	} 
}

