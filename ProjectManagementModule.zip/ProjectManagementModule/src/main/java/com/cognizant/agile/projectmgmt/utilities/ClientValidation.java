package com.cognizant.agile.projectmgmt.utilities;

import java.util.Set;

import com.cognizant.agile.projectmgmt.dto.ClientDTO;

//import com.cognizant.dto.ProjectDTO;

import jakarta.validation.*;

public class ClientValidation {
	public static void validateClient(ClientDTO CDTO) {
		Validator validator=Validation.buildDefaultValidatorFactory().getValidator();
		Set<ConstraintViolation<ClientDTO>> violations=validator.validate(CDTO);
		
		if(!violations.isEmpty()) {
			throw new ConstraintViolationException(violations);
		}
	}
}
