package com.cognizant.agile.projectmgmt.dto;

import java.util.Date;

import org.hibernate.validator.constraints.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.*;

import lombok.Data;

@Data
public class ProjectDTO {
	private int projectCode;
	
	@Length(min=3,max=50)
	private String title;
	
	private int budget;
	
	private Date startDate;
	
	private Date expectedEndDate;
	
	private Date createdOn;
	
	@Length(max=20)
	@Pattern(regexp="^(New|InProgress|Completed|Delayed|Cancelled)$")
	private String status;
	
	private Date lastUpdatedOn;
	
//	private ClientDTO clientDTO;
	
	private int clientId;
	
	@JsonIgnore
	@AssertTrue(message="Expected_End_Date must be after Start_Date")
	public boolean isExpectedEndDateAfterStartDate() {
		return expectedEndDate.after(startDate);
	}

}
