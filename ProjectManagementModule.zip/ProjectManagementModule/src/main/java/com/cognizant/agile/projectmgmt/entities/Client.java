package com.cognizant.agile.projectmgmt.entities;

import jakarta.persistence.*;

import lombok.Data;

@Data
@Entity
@Table(name="Clients")
public class Client {
	@Id
	@Column(name="Id") 
	private int id;

	@Column(name="Name")
	private String name;

	@Column(name="POC_Full_Name")
	private int fullName;
	
	@Column(name="POC_Phone_Number")
	private String phoneNumber;
	
	@Column(name="POC_Email_Address")
	private String emailAddress;
	
}
