package com.cognizant.agile.projectmgmt.dto;

import org.hibernate.validator.constraints.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.Pattern;

import lombok.*;

@Data
public class ResourceDTO {
	
	@JsonIgnore
	@Length(min=6, max=6)
	private String userId;
	
	@Length(min=3,max=15)
	private String firstName;
	 
	@Length(min=3,max=15)
	private String lastName;
	
	@Length(max=50)
	private String email;
	
	@Length(max=10)
	private String phoneNumber;
	
	@Length(max=20)
	@Pattern(regexp="^(Developer|Tester)$")
	private String role;
	
//	private ProjectDTO projectDTO;
	
	private int projectCode;

}
