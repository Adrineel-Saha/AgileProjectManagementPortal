package com.cognizant.agile.projectmgmt.services;

import java.util.List;

import com.cognizant.agile.projectmgmt.dto.UserDTO;
import com.cognizant.agile.projectmgmt.entities.Users;

public interface UserService {

	public List<Users> listOfUsers();
	public UserDTO authenticateUser(String username,String password);
}
